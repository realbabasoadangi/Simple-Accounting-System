﻿namespace SimpleaccountingSys
{


    public partial class DataSet1
    {
    }
}
namespace SimpleaccountingSys {
    
    
    public partial class DataSet1 {
    }
}
